package com.example.listview3;

public class Student implements CharSequence {
	
	int image;
	String fullname, course;
	public Student(int image, String fullname, String course) {
		super();
		this.image = image;
		this.fullname = fullname;
		this.course = course;
	}
	public int getImage() {
		return image;
	}
	public void setImage(int image) {
		this.image = image;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	@Override
	public char charAt(int arg0) {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public int length() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public CharSequence subSequence(int arg0, int arg1) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
